package com.sena.backedservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackedServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackedServiceApplication.class, args);
	}

}
