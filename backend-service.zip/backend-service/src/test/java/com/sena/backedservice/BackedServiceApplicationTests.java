package com.sena.backedservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackedServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
